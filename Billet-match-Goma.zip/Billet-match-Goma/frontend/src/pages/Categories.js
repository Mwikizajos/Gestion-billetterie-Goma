import React, { useState, useEffect } from 'react';
import API from '../api/axiosConfig';
import { Tag, PlusCircle, Trash2, CheckCircle2 } from 'lucide-react';
import './Categories.css';

const Categories = () => {
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(false);

  const [typeCategorie, setTypeCategorie] = useState('amical');

  const fetchCategories = async () => {
    setLoading(true);
    try {
      const res = await API.get('/categorie');
      setCategories(res.data || []);
    } catch (err) {
      console.error(err.response?.data || err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCategories();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await API.post('/categorie', {
        types_categorie: typeCategorie
      });

      fetchCategories();
    } catch (err) {
      alert(err.response?.data?.error || "Erreur ajout catégorie");
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm("Supprimer cette catégorie ?")) {
      try {
        await API.delete(`/categorie/${id}`);
        fetchCategories();
      } catch (err) {
        alert(err.response?.data?.error || "Erreur suppression");
      }
    }
  };

  return (
    <div className="cat-container">

      <h2 className="cat-title">
        <Tag /> Catégories de Match
      </h2>

      {/* FORM */}
      <form onSubmit={handleSubmit} className="cat-form">

        <label>
          <input
            type="radio"
            value="amical"
            checked={typeCategorie === "amical"}
            onChange={(e) => setTypeCategorie(e.target.value)}
          />
          Amical
        </label>

        <label>
          <input
            type="radio"
            value="championat"
            checked={typeCategorie === "championat"}
            onChange={(e) => setTypeCategorie(e.target.value)}
          />
          Championnat
        </label>

        <button type="submit">
          <PlusCircle size={18} /> Ajouter
        </button>
      </form>

      {/* LIST */}
      {loading ? (
        <p className="cat-loading">Chargement...</p>
      ) : categories.length === 0 ? (
        <p className="cat-empty">Aucune catégorie</p>
      ) : (
        <div className="cat-list">

          {categories.map((cat) => (
            <div key={cat.id} className="cat-item">

              <div className="cat-info">
                <CheckCircle2 size={18} />
                <span>{cat.types_categorie}</span>
              </div>

              <button onClick={() => handleDelete(cat.id)}>
                <Trash2 size={16} />
              </button>

            </div>
          ))}

        </div>
      )}

    </div>
  );
};

export default Categories;