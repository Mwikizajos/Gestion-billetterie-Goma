import React, { useEffect, useState } from 'react';
import matchService from '../services/matchService';
import { Trophy } from 'lucide-react';

const Home = () => {
  const [matchs, setMatchs] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Cette fonction s'exécute au chargement de la page
    const fetchMatchs = async () => {
      try {
        const data = await matchService.getAllMatchs();
        setMatchs(data);
      } catch (error) {
        console.error("Erreur lors de la récupération des matchs:", error);
        alert("Impossible de charger les matchs. Vérifie si le serveur est lancé !");
      } finally {
        setLoading(false);
      }
    };

    fetchMatchs();
  }, []);

  if (loading) return <p style={{ textAlign: 'center' }}>Chargement des matchs en cours...</p>;

  return (
    <div style={{ padding: '20px' }}>
      <h2 style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
        <Trophy color="#f1c40f" /> Matchs Disponibles
      </h2>
      
      <div style={gridStyle}>
        {matchs.length > 0 ? (
          matchs.map((m) => (
            <div key={m.id_match} style={matchCard}>
              <h3>{m.equipe_domicile} vs {m.equipe_exterieur}</h3>
              <p>🏟️ Stade : {m.nom_stade}</p>
              <p>📅 Date : {new Date(m.date_match).toLocaleDateString()}</p>
              <button style={btnReserve}>Réserver</button>
            </div>
          ))
        ) : (
          <p>Aucun match prévu pour le moment.</p>
        )}
      </div>
    </div>
  );
};

const gridStyle = {
  display: 'grid',
  gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))',
  gap: '20px',
  marginTop: '20px'
};

const matchCard = {
  border: '1px solid #ddd',
  borderRadius: '10px',
  padding: '15px',
  backgroundColor: '#fff',
  boxShadow: '0 2px 5px rgba(0,0,0,0.05)'
};

const btnReserve = {
  width: '100%',
  padding: '10px',
  backgroundColor: '#27ae60',
  color: 'white',
  border: 'none',
  borderRadius: '5px',
  cursor: 'pointer'
};

export default Home;