import React, { useState, useEffect } from 'react';
import API from '../api/axiosConfig';
import { Shield, Search, ChevronLeft, ChevronRight, Trash2, Plus } from 'lucide-react';
import './Equipes.css';

const Equipes = () => {
  const [equipes, setEquipes] = useState([]);
  const [loading, setLoading] = useState(false);

  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);

  const [formData, setFormData] = useState({
    Nom_equipe: '',
    sigle_equipe: '',
    ville: ''
  });

  const fetchEquipes = async () => {
    setLoading(true);
    try {
      const res = await API.get(
        `/equipe?page=${currentPage}&limit=5&nom=${searchTerm}`
      );

      setEquipes(res.data.data || []);
      setTotalPages(res.data.totalPages || 1);
    } catch (err) {
      console.error(err.response?.data || err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchEquipes();
  }, [currentPage, searchTerm]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await API.post('/equipe', formData);
      setFormData({ Nom_equipe: '', sigle_equipe: '', ville: '' });
      fetchEquipes();
    } catch (err) {
      alert(err.response?.data?.error || "Erreur ajout équipe");
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm("Supprimer cette équipe ?")) {
      try {
        await API.delete(`/equipe/${id}`);
        fetchEquipes();
      } catch (err) {
        alert(err.response?.data?.error || "Erreur suppression");
      }
    }
  };

  return (
    <div className="eq-container">

      <h2 className="eq-title">
        <Shield /> Gestion des Clubs
      </h2>

      {/* FORM */}
      <form onSubmit={handleSubmit} className="eq-form">
        <input
          placeholder="Nom équipe"
          value={formData.Nom_equipe}
          onChange={(e) =>
            setFormData({ ...formData, Nom_equipe: e.target.value })
          }
          required
        />

        <input
          placeholder="Sigle"
          value={formData.sigle_equipe}
          onChange={(e) =>
            setFormData({ ...formData, sigle_equipe: e.target.value })
          }
          required
        />

        <input
          placeholder="Ville"
          value={formData.ville}
          onChange={(e) =>
            setFormData({ ...formData, ville: e.target.value })
          }
          required
        />

        <button type="submit">
          <Plus size={18} /> Ajouter
        </button>
      </form>

      {/* SEARCH */}
      <div className="eq-search">
        <Search size={18} />
        <input
          placeholder="Rechercher une équipe..."
          value={searchTerm}
          onChange={(e) => {
            setSearchTerm(e.target.value);
            setCurrentPage(1);
          }}
        />
      </div>

      {/* TABLE */}
      <div className="eq-table">
        {loading ? (
          <p className="eq-loading">Chargement...</p>
        ) : equipes.length === 0 ? (
          <p className="eq-empty">Aucune équipe trouvée</p>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Sigle</th>
                <th>Nom</th>
                <th>Ville</th>
                <th></th>
              </tr>
            </thead>

            <tbody>
              {equipes.map((eq) => (
                <tr key={eq.id}>
                  <td className="sigle">{eq.sigle_equipe}</td>
                  <td>{eq.Nom_equipe}</td>
                  <td>{eq.ville}</td>
                  <td>
                    <button onClick={() => handleDelete(eq.id)}>
                      <Trash2 size={16} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* PAGINATION */}
      <div className="eq-pagination">
        <button
          disabled={currentPage === 1}
          onClick={() => setCurrentPage((p) => p - 1)}
        >
          <ChevronLeft />
        </button>

        <span>
          {currentPage} / {totalPages}
        </span>

        <button
          disabled={currentPage === totalPages}
          onClick={() => setCurrentPage((p) => p + 1)}
        >
          <ChevronRight />
        </button>
      </div>
    </div>
  );
};

export default Equipes;