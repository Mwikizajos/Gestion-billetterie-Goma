import React, { useEffect, useState } from "react";
import API from "../api/axiosConfig";
import {
  Calendar,
  MapPin,
  Trash2,
  PlusCircle,
  Pencil
} from "lucide-react";
import "./Matchs.css";

const Matchs = () => {
  const [matchs, setMatchs] = useState([]);
  const [equipes, setEquipes] = useState([]);
  const [stades, setStades] = useState([]);
  const [categories, setCategories] = useState([]);

  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");
  const [editingId, setEditingId] = useState(null);

  const [formData, setFormData] = useState({
    equipe_domicile: "",
    equipe_exterieur: "",
    stade: "",
    idCategorie_match: "",
    date_match: ""
  });

  const fetchAllData = async () => {
    try {
      setLoading(true);

      const [resM, resE, resS, resC] = await Promise.all([
        API.get("/match"),
        API.get("/equipe?limit=100"),
        API.get("/stade"),
        API.get("/categorie")
      ]);

      setMatchs(resM.data);
      setEquipes(resE.data.data || resE.data);
      setStades(resS.data);
      setCategories(resC.data);

    } catch (error) {
      console.error(error);
      setMessage("Erreur lors du chargement des données");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAllData();
  }, []);

  const resetForm = () => {
    setFormData({
      equipe_domicile: "",
      equipe_exterieur: "",
      stade: "",
      idCategorie_match: "",
      date_match: ""
    });
    setEditingId(null);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      if (editingId) {
        await API.put(`/match/${editingId}`, formData);
        setMessage("Match modifié avec succès");
      } else {
        await API.post("/match", formData);
        setMessage("Match programmé avec succès");
      }

      resetForm();
      fetchAllData();

    } catch (err) {
      setMessage(
        err.response?.data?.error ||
          "Erreur lors de l'enregistrement"
      );
    }
  };

  const handleEdit = (match) => {
    setFormData({
      equipe_domicile: match.equipe_domicile || "",
      equipe_exterieur: match.equipe_exterieur || "",
      stade: match.stade || "",
      idCategorie_match: match.idCategorie_match || "",
      date_match: match.date_match?.slice(0, 16)
    });

    setEditingId(match.id);
  };

  const handleDelete = async (id) => {
    const confirmDelete = window.confirm(
      "Voulez-vous vraiment supprimer ce match ?"
    );

    if (!confirmDelete) return;

    try {
      await API.delete(`/matchs/${id}`);
      setMessage("Match supprimé");
      fetchAllData();
    } catch (error) {
      setMessage("Erreur de suppression");
    }
  };

  return (
    <div className="match-container">
      <h2 className="match-title">
        <Calendar /> Gestion des Matchs
      </h2>

      {message && (
        <div className="message-box">
          {message}
        </div>
      )}

      <form className="match-form" onSubmit={handleSubmit}>
        <select
          value={formData.equipe_domicile}
          onChange={(e) =>
            setFormData({
              ...formData,
              equipe_domicile: e.target.value
            })
          }
          required
        >
          <option value="">Equipe domicile</option>
          {equipes.map((e) => (
            <option key={e.id} value={e.id}>
              {e.Nom_equipe}
            </option>
          ))}
        </select>

        <select
          value={formData.equipe_exterieur}
          onChange={(e) =>
            setFormData({
              ...formData,
              equipe_exterieur: e.target.value
            })
          }
          required
        >
          <option value="">Equipe extérieure</option>
          {equipes.map((e) => (
            <option key={e.id} value={e.id}>
              {e.Nom_equipe}
            </option>
          ))}
        </select>

        <select
          value={formData.stade}
          onChange={(e) =>
            setFormData({
              ...formData,
              stade: e.target.value
            })
          }
          required
        >
          <option value="">Choisir stade</option>
          {stades.map((s) => (
            <option key={s.id} value={s.id}>
              {s.nom_stade}
            </option>
          ))}
        </select>

        <select
          value={formData.idCategorie_match}
          onChange={(e) =>
            setFormData({
              ...formData,
              idCategorie_match: e.target.value
            })
          }
          required
        >
          <option value="">Catégorie</option>
          {categories.map((c) => (
            <option key={c.id} value={c.id}>
              {c.types_categorie}
            </option>
          ))}
        </select>

        <input
          type="datetime-local"
          value={formData.date_match}
          onChange={(e) =>
            setFormData({
              ...formData,
              date_match: e.target.value
            })
          }
          required
        />

        <button type="submit">
          <PlusCircle size={18} />
          {editingId ? "Modifier" : "Programmer"}
        </button>
      </form>

      {loading ? (
        <p className="loading-text">Chargement...</p>
      ) : matchs.length === 0 ? (
        <p className="empty-text">Aucun match programmé</p>
      ) : (
        <div className="match-grid">
          {matchs.map((match) => (
            <div className="match-card" key={match.id}>
              <div className="match-header">
                <span className="category-badge">
                  {match.types_categorie}
                </span>

                <div className="actions">
                  <button
                    className="edit-btn"
                    onClick={() => handleEdit(match)}
                  >
                    <Pencil size={16} />
                  </button>

                  <button
                    className="delete-btn"
                    onClick={() => handleDelete(match.id)}
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>

              <div className="versus">
                <h3>{match.domicile}</h3>
                <span>VS</span>
                <h3>{match.exterieur}</h3>
              </div>

              <div className="match-info">
                <p>
                  <MapPin size={14} /> {match.nom_stade}
                </p>

                <p>
                  <Calendar size={14} />
                  {new Date(match.date_match).toLocaleString("fr-FR")}
                </p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Matchs;