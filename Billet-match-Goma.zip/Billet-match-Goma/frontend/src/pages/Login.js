import React, { useState, useEffect } from "react";
import authService from "../services/authService";
import { LogIn, Phone, Lock } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import "./Login.css";

const Login = ({ onLoginSuccess }) => {
  const [credentials, setCredentials] = useState({
    telephone: "",
    password: "",
  });

  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const navigate = useNavigate();

  // Vérifie si utilisateur déjà connecté
  useEffect(() => {
    const token = localStorage.getItem("token");

    if (token) {
      navigate("/match");
    }
  }, [navigate]);

  const handleChange = (e) => {
    const { name, value } = e.target;

    setCredentials((prev) => ({
      ...prev,
      [name]: value.trimStart(),
    }));

    // Supprime message erreur quand utilisateur recommence
    if (error) {
      setError("");
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!credentials.telephone || !credentials.password) {
      setError("Veuillez remplir tous les champs");
      return;
    }

    setLoading(true);

    try {
      const response = await authService.login(
        credentials.telephone,
        credentials.password
      );

      console.log("Connexion réussie :", response);

      if (onLoginSuccess) {
        onLoginSuccess(response.user);
      }

      // redirection automatique
      if(response.role === "admin"){
        navigate("/matchs")
      } else{
        navigate("/")
      }
    } catch (err) {
      console.log("Erreur serveur détaillée :", err.response?.data);

      setError(
        err.response?.data?.message ||
          err.response?.data?.error ||
          "Erreur de connexion au serveur"
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-container">
      <div className="overlay"></div>

      <form onSubmit={handleSubmit} className="login-card">
        <div className="login-header">
          <LogIn size={32} />
          <h2>Connexion</h2>
          <p>Accédez au système de billetterie</p>
        </div>

        {error && <div className="error-msg">{error}</div>}

        <div className="input-group">
          <Phone className="input-icon" size={18} />
          <input
            type="tel"
            name="telephone"
            placeholder="Numéro de téléphone"
            className="login-input"
            value={credentials.telephone}
            onChange={handleChange}
            required
          />
        </div>

        <div className="input-group">
          <Lock className="input-icon" size={18} />
          <input
            type="password"
            name="password"
            placeholder="Mot de passe"
            className="login-input"
            value={credentials.password}
            onChange={handleChange}
            required
          />
        </div>

        <button
          type="submit"
          disabled={loading}
          className={`login-button ${loading ? "loading" : ""}`}
        >
          {loading ? "Connexion..." : "Entrer sur le terrain"}
        </button>

        <p className="register-link">
          Pas encore de compte ?{" "}
          <Link to="/register">Inscrivez-vous ici</Link>
        </p>
      </form>
    </div>
  );
};

export default Login;