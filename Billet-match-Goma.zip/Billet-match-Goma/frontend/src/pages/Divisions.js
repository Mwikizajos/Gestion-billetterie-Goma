import React, { useState, useEffect } from 'react';
import API from '../api/axiosConfig';
import { Layers, Plus, Trash2, Edit } from 'lucide-react';
import './Divisions.css';

const Divisions = () => {
  const [divisions, setDivisions] = useState([]);
  const [nomDivision, setNomDivision] = useState('');
  const [editingId, setEditingId] = useState(null);

  // Charger divisions
  const fetchDivisions = async () => {
    try {
      const res = await API.get('/division');
      setDivisions(res.data);
    } catch (err) {
      console.error(err.response?.data || err.message);
    }
  };

  useEffect(() => {
    fetchDivisions();
  }, []);

  // Ajouter ou modifier
  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!nomDivision.trim()) {
      return alert("Entrez un nom de division");
    }

    try {
      if (editingId) {
        await API.put(`/division/${editingId}`, {
          nom_division: nomDivision
        });
        alert("Division modifiée !");
      } else {
        await API.post('/division', {
          nom_division: nomDivision
        });
        alert("Division ajoutée !");
      }

      setNomDivision('');
      setEditingId(null);
      fetchDivisions();

    } catch (err) {
      alert(err.response?.data?.error || "Erreur");
    }
  };

  // Supprimer
  const handleDelete = async (id) => {
    if (window.confirm("Supprimer cette division ?")) {
      try {
        await API.delete(`/division/${id}`);
        fetchDivisions();
      } catch (err) {
        alert(err.response?.data?.error || "Erreur suppression");
      }
    }
  };

  // Préparer modification
  const handleEdit = (division) => {
    setNomDivision(division.nom_division);
    setEditingId(division.id);
  };

  return (
    <div className="division-container">
      <h2 className="division-title">
        <Layers size={25} color="#8e44ad" />
        Gestion des Divisions
      </h2>

      {/* Formulaire */}
      <form className="division-form" onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Nom division (ex: Division 1)"
          value={nomDivision}
          onChange={(e) => setNomDivision(e.target.value)}
        />

        <button type="submit">
          <Plus size={18} />
          {editingId ? "Modifier" : "Ajouter"}
        </button>
      </form>

      {/* Liste */}
      <div className="division-list">
        {divisions.length > 0 ? (
          divisions.map((div) => (
            <div className="division-item" key={div.id}>
              <span>{div.nom_division}</span>

              <div className="actions">
                <button
                  className="edit-btn"
                  onClick={() => handleEdit(div)}
                >
                  <Edit size={16} />
                </button>

                <button
                  className="delete-btn"
                  onClick={() => handleDelete(div.id)}
                >
                  <Trash2 size={16} />
                </button>
              </div>
            </div>
          ))
        ) : (
          <p>Aucune division enregistrée.</p>
        )}
      </div>
    </div>
  );
};

export default Divisions;