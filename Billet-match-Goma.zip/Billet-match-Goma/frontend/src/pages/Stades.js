import React, { useState, useEffect } from 'react';
import API from '../api/axiosConfig';
import { MapPin, Users, Star, Trash2, PlusCircle } from 'lucide-react';
import './Stades.css';

const Stades = () => {
  const [stades, setStades] = useState([]);
  const [loading, setLoading] = useState(false);

  const [formData, setFormData] = useState({
    nom_stade: '',
    capacite: '',
    capacite_place_VIP: '',
    adresse: ''
  });

  const fetchStades = async () => {
    setLoading(true);
    try {
      const res = await API.get('/stade');
      setStades(res.data || []);
    } catch (err) {
      console.error(err.response?.data || err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStades();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await API.post('/stade', formData);

      setFormData({
        nom_stade: '',
        capacite: '',
        capacite_place_VIP: '',
        adresse: ''
      });

      fetchStades();
    } catch (err) {
      alert(err.response?.data?.error || "Erreur ajout stade");
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm("Supprimer ce stade ?")) {
      try {
        await API.delete(`/stade/${id}`);
        fetchStades();
      } catch (err) {
        alert(err.response?.data?.error || "Erreur suppression");
      }
    }
  };

  return (
    <div className="st-container">

      <h2 className="st-title">
        <MapPin /> Gestion des Stades
      </h2>

      {/* FORM */}
      <form onSubmit={handleSubmit} className="st-form">

        <input
          placeholder="Nom du stade"
          value={formData.nom_stade}
          onChange={(e) =>
            setFormData({ ...formData, nom_stade: e.target.value })
          }
          required
        />

        <input
          type="number"
          placeholder="Capacité"
          value={formData.capacite}
          onChange={(e) =>
            setFormData({ ...formData, capacite: e.target.value })
          }
          required
        />

        <input
          type="number"
          placeholder="Capacité VIP"
          value={formData.capacite_place_VIP}
          onChange={(e) =>
            setFormData({ ...formData, capacite_place_VIP: e.target.value })
          }
          required
        />

        <input
          placeholder="Adresse"
          value={formData.adresse}
          onChange={(e) =>
            setFormData({ ...formData, adresse: e.target.value })
          }
          required
        />

        <button type="submit">
          <PlusCircle size={18} /> Ajouter
        </button>
      </form>

      {/* LISTE */}
      {loading ? (
        <p className="st-loading">Chargement...</p>
      ) : stades.length === 0 ? (
        <p className="st-empty">Aucun stade enregistré</p>
      ) : (
        <div className="st-grid">
          {stades.map((stade) => (
            <div key={stade.id} className="st-card">

              <button
                className="st-delete"
                onClick={() => handleDelete(stade.id)}
              >
                <Trash2 size={16} />
              </button>

              <h3>{stade.nom_stade}</h3>
              <p className="st-address">📍 {stade.adresse}</p>

              <div className="st-badges">
                <span>
                  <Users size={14} /> {stade.capacite}
                </span>

                <span className="vip">
                  <Star size={14} /> {stade.capacite_place_VIP}
                </span>
              </div>

            </div>
          ))}
        </div>
      )}

    </div>
  );
};

export default Stades;