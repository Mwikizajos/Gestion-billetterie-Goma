import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import API from "../api/axiosConfig";
import {
  UserPlus,
  User,
  Phone,
  Lock,
  CheckCircle
} from "lucide-react";
import "./Register.css";

const Register = () => {
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    nom: "",
    telephone: "",
    password: "",
    confirmPassword: ""
  });

  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;

    setFormData((prev) => ({
      ...prev,
      [name]: value
    }));

    setError("");
    setSuccess("");
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (
      !formData.nom ||
      !formData.telephone ||
      !formData.password ||
      !formData.confirmPassword
    ) {
      return setError("Veuillez remplir tous les champs.");
    }

    if (formData.password !== formData.confirmPassword) {
      return setError("Les mots de passe ne correspondent pas.");
    }

    if (formData.telephone.length < 10) {
      return setError("Numéro de téléphone invalide.");
    }

    try {
      setLoading(true);

      await API.post("/utilisateurs/register", {
        nom: formData.nom.trim(),
        telephone: formData.telephone.trim(),
        password: formData.password
      });

      setSuccess("Compte créé avec succès ! Redirection...");

      setTimeout(() => {
        navigate("/login");
      }, 1500);

    } catch (err) {
      console.log(err.response?.data);

      setError(
        err.response?.data?.message ||
        err.response?.data?.error ||
        "Erreur lors de l'inscription"
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="register-container">
      <div className="register-overlay"></div>

      <div className="register-card">
        <div className="register-header">
          <UserPlus size={35} />
          <h2>Créer un compte</h2>
          <p>Rejoignez la plateforme de billetterie</p>
        </div>

        {error && <div className="error-msg">{error}</div>}
        {success && <div className="success-msg">{success}</div>}

        <form onSubmit={handleSubmit} className="register-form">

          <div className="input-group">
            <User className="input-icon" size={18} />
            <input
              type="text"
              name="nom"
              placeholder="Nom complet"
              className="register-input"
              value={formData.nom}
              onChange={handleChange}
            />
          </div>

          <div className="input-group">
            <Phone className="input-icon" size={18} />
            <input
              type="text"
              name="telephone"
              placeholder="Numéro de téléphone"
              className="register-input"
              value={formData.telephone}
              onChange={handleChange}
            />
          </div>

          <div className="input-group">
            <Lock className="input-icon" size={18} />
            <input
              type="password"
              name="password"
              placeholder="Mot de passe"
              className="register-input"
              value={formData.password}
              onChange={handleChange}
            />
          </div>

          <div className="input-group">
            <CheckCircle className="input-icon" size={18} />
            <input
              type="password"
              name="confirmPassword"
              placeholder="Confirmer mot de passe"
              className="register-input"
              value={formData.confirmPassword}
              onChange={handleChange}
            />
          </div>

          <button
            type="submit"
            className={`register-button ${loading ? "loading" : ""}`}
            disabled={loading}
          >
            {loading ? "Création..." : "Rejoindre le club"}
          </button>
        </form>

        <p className="login-link">
          Déjà inscrit ? <Link to="/login">Connectez-vous ici</Link>
        </p>
      </div>
    </div>
  );
};

export default Register;