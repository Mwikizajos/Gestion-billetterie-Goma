import React, { useState, useEffect } from 'react';
import API from '../api/axiosConfig';
import { DollarSign, Ticket, Trash2 } from 'lucide-react';

const Tarifs = () => {
  const [matchs, setMatchs] = useState([]);
  const [selectedMatch, setSelectedMatch] = useState('');
  const [tarifs, setTarifs] = useState([]);

  const [formData, setFormData] = useState({
    type_place: 'Standard',
    prix: '',
    nombre_places_total: ''
  });

  useEffect(() => {
    fetchMatchs();
  }, []);

  const fetchMatchs = async () => {
    try {
      const res = await API.get('/match');
      setMatchs(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  const fetchTarifs = async (matchId) => {
    try {
      const res = await API.get(`/tarifs/match/${matchId}`);
      setTarifs(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    if (selectedMatch) {
      fetchTarifs(selectedMatch);
    } else {
      setTarifs([]);
    }
  }, [selectedMatch]);

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!selectedMatch) {
      return alert("Choisissez un match");
    }

    try {
      await API.post('/tarifs', {
        idMatch: selectedMatch,
        type_place: formData.type_place,
        prix: parseFloat(formData.prix),
        nombre_places_total: parseInt(formData.nombre_places_total)
      });

      alert("Tarif ajouté");

      setFormData({
        type_place: 'Standard',
        prix: '',
        nombre_places_total: ''
      });

      fetchTarifs(selectedMatch);

    } catch (err) {
      alert(err.response?.data?.error || "Erreur");
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm("Supprimer ce tarif ?")) {
      try {
        await API.delete(`/tarifs/${id}`);
        fetchTarifs(selectedMatch);
      } catch (err) {
        alert("Erreur suppression");
      }
    }
  };

  return (
    <div style={containerStyle}>
      <h2>
        <DollarSign color="#2ecc71" /> Gestion Tarifs
      </h2>

      <div style={selectionBox}>
        <label>Choisir un match :</label>

        <select
          value={selectedMatch}
          onChange={(e) => setSelectedMatch(e.target.value)}
          style={selectStyle}
        >
          <option value="">-- Sélectionner --</option>

          {matchs.map((m) => (
            <option key={m.id} value={m.id}>
              {m.domicile} vs {m.exterieur}
            </option>
          ))}
        </select>
      </div>

      {selectedMatch && (
        <>
          <form onSubmit={handleSubmit} style={formStyle}>
            <select
              value={formData.type_place}
              onChange={(e) =>
                setFormData({
                  ...formData,
                  type_place: e.target.value
                })
              }
              style={inputStyle}
            >
              <option value="Standard">Standard</option>
              <option value="VIP">VIP</option>
            </select>

            <input
              type="number"
              placeholder="Prix"
              required
              value={formData.prix}
              onChange={(e) =>
                setFormData({
                  ...formData,
                  prix: e.target.value
                })
              }
              style={inputStyle}
            />

            <input
              type="number"
              placeholder="Nombre de places"
              required
              value={formData.nombre_places_total}
              onChange={(e) =>
                setFormData({
                  ...formData,
                  nombre_places_total: e.target.value
                })
              }
              style={inputStyle}
            />

            <button type="submit" style={btnSubmit}>
              Ajouter
            </button>
          </form>

          <div style={tarifList}>
            {tarifs.map((t) => (
              <div key={t.id} style={tarifCard}>
                <Ticket size={20} />

                <div style={{ flex: 1 }}>
                  <strong>{t.type_place}</strong>
                  <p>
                    {t.prix} FC - {t.nombre_places_total} places
                  </p>
                </div>

                <button
                  onClick={() => handleDelete(t.id)}
                  style={btnDelete}
                >
                  <Trash2 size={18} />
                </button>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
};

export default Tarifs;

const containerStyle = {
  padding: '20px',
  maxWidth: '900px',
  margin: '0 auto'
};

const selectionBox = {
  background: '#ecf0f1',
  padding: '15px',
  borderRadius: '8px',
  marginBottom: '20px'
};

const selectStyle = {
  width: '100%',
  padding: '10px',
  marginTop: '10px'
};

const formStyle = {
  display: 'flex',
  gap: '10px',
  marginBottom: '20px',
  flexWrap: 'wrap'
};

const inputStyle = {
  padding: '10px',
  flex: 1
};

const btnSubmit = {
  padding: '10px 20px',
  backgroundColor: '#2ecc71',
  color: 'white',
  border: 'none',
  cursor: 'pointer'
};

const tarifList = {
  display: 'grid',
  gap: '10px'
};

const tarifCard = {
  display: 'flex',
  alignItems: 'center',
  gap: '10px',
  background: 'white',
  padding: '15px',
  borderRadius: '8px',
  border: '1px solid #ddd'
};

const btnDelete = {
  background: 'none',
  border: 'none',
  color: 'red',
  cursor: 'pointer'
};