import React, { useState, useEffect } from 'react';
import API from '../api/axiosConfig';
import { Trophy, Trash2, PlusCircle, Layers } from 'lucide-react';
import "./Championnats.css";

const Championnats = () => {
  const [championnats, setChampionnats] = useState([]);
  const [divisions, setDivisions] = useState([]);

  const [formData, setFormData] = useState({
    nom_championat: '',
    idDivision: ''
  });

  // Charger championnats + divisions
  const fetchData = async () => {
    try {
      const champRes = await API.get('/championnat');
      const divRes = await API.get('/division');

      setChampionnats(champRes.data);
      setDivisions(divRes.data);

    } catch (err) {
      console.error(err.response?.data || err.message);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  // Ajouter championnat
  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!formData.nom_championat || !formData.idDivision) {
      return alert("Tous les champs sont requis");
    }

    try {
      await API.post('/championnats', formData);

      alert("Championnat ajouté avec succès");

      setFormData({
        nom_championat: '',
        idDivision: ''
      });

      fetchData();

    } catch (err) {
      alert(err.response?.data?.error || "Erreur ajout");
    }
  };

  // Supprimer
  const handleDelete = async (id) => {
    if (window.confirm("Supprimer ce championnat ?")) {
      try {
        await API.delete(`/championnat/${id}`);
        fetchData();
      } catch (err) {
        alert(err.response?.data?.error || "Erreur suppression");
      }
    }
  };

  return (
    <div className="champ-container">
      <h2 className="title">
        <Trophy size={25} color="#f39c12" />
        Gestion des Championnats
      </h2>

      {/* Formulaire */}
      <form className="champ-form" onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Nom championnat"
          value={formData.nom_championat}
          onChange={(e) =>
            setFormData({
              ...formData,
              nom_championat: e.target.value
            })
          }
        />

        <select
          value={formData.idDivision}
          onChange={(e) =>
            setFormData({
              ...formData,
              idDivision: e.target.value
            })
          }
        >
          <option value="">Choisir division</option>

          {divisions.map((div) => (
            <option key={div.id} value={div.id}>
              {div.nom_division}
            </option>
          ))}
        </select>

        <button type="submit">
          <PlusCircle size={18} />
          Ajouter
        </button>
      </form>

      {/* Liste */}
      <div className="champ-grid">
        {championnats.map((champ) => (
          <div key={champ.id} className="champ-card">
            <div className="card-header">
              <Layers size={20} color="#3498db" />

              <button
                onClick={() => handleDelete(champ.id)}
                className="delete-btn"
              >
                <Trash2 size={18} />
              </button>
            </div>

            <h3>{champ.nom_championat}</h3>

            <span className="division-badge">
              {champ.nom_division}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Championnats;