import React, { useEffect, useState } from "react";
import API from "../api/axiosConfig" ;
import { QRCodeSVG } from "qrcode.react";
import {
  Ticket,
  Search,
  User,
  CheckCircle,
  XCircle,
  Trash2
} from "lucide-react";
import "./Billets.css";

const Billets = () => {
  const [billets, setBillets] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");

  const fetchBillets = async () => {
    try {
      setLoading(true);

      const res = await API.get("/billet");
      setBillets(res.data);

    } catch (err) {
      console.error(err);
      setMessage("Erreur lors du chargement des billets");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBillets();
  }, []);

  const handleInvalidate = async (id) => {
    const confirmAction = window.confirm(
      "Voulez-vous invalider ce billet ?"
    );

    if (!confirmAction) return;

    try {
      await API.put(`/billet/invalidate/${id}`);
      setMessage("Billet invalidé avec succès");
      fetchBillets();
    } catch (err) {
      setMessage("Erreur lors de l'invalidation");
    }
  };

  const filteredBillets = billets.filter((b) =>
    b.nom.toLowerCase().includes(searchTerm.toLowerCase()) ||
    b.codeQR.toLowerCase().includes(searchTerm.toLowerCase()) ||
    b.type_place.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="billets-container">
      <div className="billets-header">
        <h2>
          <Ticket size={28} />
          Gestion des Billets
        </h2>

        <div className="search-box">
          <Search size={18} />
          <input
            type="text"
            placeholder="Rechercher billet..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      {message && (
        <div className="message-box">
          {message}
        </div>
      )}

      {loading ? (
        <p className="loading-text">Chargement...</p>
      ) : filteredBillets.length === 0 ? (
        <p className="empty-text">
          Aucun billet trouvé
        </p>
      ) : (
        <div className="billets-grid">
          {filteredBillets.map((billet) => (
            <div
              className={`ticket-card ${
                !billet.estValide ? "invalid-ticket" : "" 
              }`}
              key={billet.id}
            >
              <div className="ticket-left" >
                <QRCodeSVG
                  value={billet.codeQR}
                  size={90}
                />

                <small>
                  {billet.codeQR.substring(0, 10)}...
                </small>
              </div>

              <div className="ticket-right">
                <div className="ticket-top">
                  <span
                    className={
                      billet.estValide
                        ? "status valid"
                        : "status invalid"
                    }
                  >
                    {billet.estValide ? (
                      <CheckCircle size={14} />
                    ) : (
                      <XCircle size={14} />
                    )}

                    {billet.estValide
                      ? "VALIDE"
                      : "UTILISÉ"}
                  </span>

                  <span className="price-tag">
                    {billet.prix} FC
                  </span>
                </div>

                <h3>{billet.type_place}</h3>

                <p>
                  <User size={14} />
                  {billet.nom}
                </p>

                <p>
                  <Ticket size={14} />
                  Match #{billet.idmatch}
                </p>

                <p>
                  Date :
                  {" "}
                  {new Date(
                    billet.date_match
                  ).toLocaleDateString("fr-FR")}
                </p>

                {billet.estValide && (
                  <button
                    className="invalidate-btn"
                    onClick={() =>
                      handleInvalidate(billet.id)
                    }
                  >
                    <Trash2 size={14} />
                    Invalider
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Billets;