import React, { useState, useEffect } from 'react';
import API from '../api/axiosConfig';
import { UserPlus, Trash2 } from 'lucide-react';
import './GestionAdmin.css';

const GestionAdmins = () => {
  const [admins,setAdmins] = useState([]);
  const [formData,setFormData] = useState({
    nom:'',
    telephone:'',
    password:''
  });

  const fetchAdmins = async()=>{
    const res = await API.get('/admins');
    setAdmins(res.data);
  };

  useEffect(()=>{
    fetchAdmins();
  },[]);

  const handleSubmit = async(e)=>{
    e.preventDefault();

    await API.post('/admins',formData);

    setFormData({
      nom:'',
      telephone:'',
      password:''
    });

    fetchAdmins();
    alert("Admin créé");
  };

  const handleDelete = async(id)=>{
    await API.delete(`/admins/${id}`);
    fetchAdmins();
  };

  return (
    <div className="admin-container">
      <h2 className="admin-title">Gestion Admins</h2>

      <form onSubmit={handleSubmit} className="admin-form">
        <input
          placeholder="Nom"
          value={formData.nom}
          onChange={(e)=>setFormData({...formData,nom:e.target.value})}
        />

        <input
          placeholder="Telephone"
          value={formData.telephone}
          onChange={(e)=>setFormData({...formData,telephone:e.target.value})}
        />

        <input
          type="password"
          placeholder="Mot de passe"
          value={formData.password}
          onChange={(e)=>setFormData({...formData,password:e.target.value})}
        />

        <button type="submit" className="admin-btn">
          <UserPlus size={18}/>
          Ajouter
        </button>
      </form>

      {admins.map(admin=>(
        <div key={admin.id} className="admin-list">
          {admin.nom} - {admin.telephone}

          <button onClick={()=>handleDelete(admin.id)} className="delete-btn">
            <Trash2 size={16}/>
          </button>
        </div>
      ))}
    </div>
  )
}

export default GestionAdmins;