import React, { useEffect, useState } from 'react';
import matchService from '../services/matchService';
import { Trophy, Ticket } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const Home = () => {
  const [matchs, setMatchs] = useState([]);
  const [loading, setLoading] = useState(true);

  const navigate = useNavigate();

  useEffect(() => {
    const fetchMatchs = async () => {
      try {
        const data = await matchService.getAllMatchs();
        setMatchs(data);
      } catch (error) {
        console.error(error);
        alert("Impossible de charger les matchs");
      } finally {
        setLoading(false);
      }
    };

    fetchMatchs();
  }, []);

  if (loading) {
    return <p style={{ textAlign: 'center' }}>Chargement...</p>;
  }

  return (
    <div style={containerStyle}>
      <h2 style={titleStyle}>
        <Trophy color="#f1c40f" />
        Matchs Disponibles
      </h2>

      <div style={gridStyle}>
        {matchs.length > 0 ? (
          matchs.map((m) => (
            <div key={m.id} style={matchCard}>
              <h3>{m.equipe1} vs {m.equipe2}</h3>
              <p>🏟️ {m.nom_stade}</p>
              <p>📅 {new Date(m.date_match).toLocaleDateString()}</p>

              <button
                style={btnReserve}
                onClick={() => navigate('/acheter-billet')}
              >
                <Ticket size={18}/>
                Réserver
              </button>
            </div>
          ))
        ) : (
          <p>Aucun match disponible.</p>
        )}
      </div>
    </div>
  );
};

const containerStyle = {
  padding: '20px'
};

const titleStyle = {
  display: 'flex',
  alignItems: 'center',
  gap: '10px'
};

const gridStyle = {
  display: 'grid',
  gridTemplateColumns: 'repeat(auto-fill, minmax(280px,1fr))',
  gap: '20px',
  marginTop: '20px'
};

const matchCard = {
  background: '#fff',
  padding: '20px',
  borderRadius: '10px',
  boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
};

const btnReserve = {
  width: '100%',
  marginTop: '10px',
  padding: '10px',
  background: '#27ae60',
  color: 'white',
  border: 'none',
  borderRadius: '5px',
  cursor: 'pointer',
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  gap: '8px'
};

export default Home;