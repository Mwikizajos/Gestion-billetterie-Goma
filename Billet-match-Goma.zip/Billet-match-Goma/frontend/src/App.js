import React from 'react';
// CORRECTION ICI : On importe Routes (le vrai) et Route
import { Routes, Route } from 'react-router-dom'; 

import Navbar from './components/navbar';
import Home from './pages/Home';
import Login from './pages/Login';
import Stades from './pages/Stades';
import Championnats from './pages/Championnats';
import Billets from './pages/Billets';
import Matchs from './pages/Matchs';
import Categories from './pages/Categories';
import Equipes from './pages/Equipes';
import Divisions from './pages/Divisions';
import Tarifs from './pages/Tarifs';
import Register from './pages/Register';
import GestionAdmin from './pages/GestionAdmin';
import AchatBillet from './pages/AcheterBillet';

function App() {
  return (
    <div className="App">
      <Navbar />
      <main style={{ padding: '20px' }}>
        {/* Maintenant Routes est le bon composant, pas un doublon du Router */}
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/matchs" element={<Matchs />} />
          <Route path="/categories" element={<Categories />} />
          <Route path="/equipes" element={<Equipes />} />
          <Route path="/divisions" element={<Divisions />} />
          <Route path="/tarifs" element={<Tarifs />} />
          <Route path="/billets" element={<Billets />} />
          <Route path="/login" element={<Login />} />
          <Route path="/stades" element={<Stades />} />
          <Route path="/register" element={<Register />} />
          <Route path="/gestionadmins" element={<GestionAdmin />} />
          <Route path="/achatbillet" element={<AchatBillet />} />
          <Route path="/Championnats" element={<Championnats/>}/>
        </Routes>
      </main>
    </div>
  );
}

export default App;