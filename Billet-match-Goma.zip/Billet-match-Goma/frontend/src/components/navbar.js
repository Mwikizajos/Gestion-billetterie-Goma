import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Trophy, LogOut } from "lucide-react";
import authService from "../services/authService";
import "./Navbar.css";

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const navigate = useNavigate();

  const token = localStorage.getItem("token");

  const handleLogout = () => {
    authService.logout();
    navigate("/login");
  };

  return (
    <nav className="navbar">
      <Link to="/" className="nav-logo">
        <Trophy color="#22c55e" />
        <span>FOOT-TICKET</span>
      </Link>

      <div className="menu-toggle" onClick={() => setIsOpen(!isOpen)}>
        <div className="bar"></div>
        <div className="bar"></div>
        <div className="bar"></div>
      </div>

      <ul className={`nav-links ${isOpen ? "active" : ""}`}>
        <li>
          
          <Link to="/matchs" className="nav-item" onClick={() => setIsOpen(false)}>
            Matchs
          </Link>
        </li>

        <li>
          <Link to="/billets" className="nav-item" onClick={() => setIsOpen(false)}>
            Billets
          </Link>
        </li>

        <li>
          <Link to="/achatbillet" className="nav-item" onClick={() => setIsOpen(false)}>
            Achat Billet
          </Link>
        </li>

        <li>
          <Link to="/equipes" className="nav-item" onClick={() => setIsOpen(false)}>
            Équipes
          </Link>
        </li>

        <li>
          <Link to="/categories" className="nav-item" onClick={() => setIsOpen(false)}>
            Categories
          </Link>
        </li>

        <li>
          <Link to="/Championnats" className="nav-item" onClick={() => setIsOpen(false)}>
            Championats
          </Link>
        </li>

        <li>
          <Link to="/divisions" className="nav-item" onClick={() => setIsOpen(false)}>
            Division
          </Link>
        </li>

        <li>
          <Link to="/gestionadmins" className="nav-item" onClick={() => setIsOpen(false)}>
            Gestion Admin
          </Link>
        </li>

        <li>
          <Link to="/tarifs" className="nav-item" onClick={() => setIsOpen(false)}>
            Tarifs
          </Link>
        </li>

        <li>
          <Link to="/stades" className="nav-item" onClick={() => setIsOpen(false)}>
            Stades
          </Link>
        </li>

        {!token ? (
          <li>
            <Link
              to="/login"
              className="nav-item login"
              onClick={() => setIsOpen(false)}
            >
              Connexion
            </Link>
          </li>
        ) : (
          <li>
            <button className="logout-btn" onClick={handleLogout}>
              <LogOut size={18} />
              Déconnexion
            </button>
          </li>
        )}
      </ul>
    </nav>
  );
};

export default Navbar;