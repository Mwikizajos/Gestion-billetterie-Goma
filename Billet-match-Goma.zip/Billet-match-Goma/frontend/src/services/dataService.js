import API from '../api/axiosConfig';

export const dataService = {
  // Équipes
  getEquipes: () => API.get('/equipes' ),
  createEquipe: (data) => API.post('/equipes' , data),

  // Stades
  getStades: () => API.get('/stades'),
  
  // Championnats
  getChampionnats: () => API.get('/championnats'),
};