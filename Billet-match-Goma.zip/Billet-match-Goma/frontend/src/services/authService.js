import API from '../api/axiosConfig' ;

const login = async (telephone, password) => {
  const response = await API.post('/utilisateurs/login', {telephone, password });
  if (response.data.token) {
    localStorage.setItem('token' , response.data.token);
    localStorage.setItem('user', JSON.stringify(response.data.user));
    localStorage.setItem('role', response.data.user.role);
  }
  return response.data;
};

const logout = () => {
  localStorage.removeItem('token');
  localStorage.removeItem('user');
};

// On assigne l'objet à une variable constante
const authService = {
  login,
  logout
};

// On exporte la variable
export default authService ;