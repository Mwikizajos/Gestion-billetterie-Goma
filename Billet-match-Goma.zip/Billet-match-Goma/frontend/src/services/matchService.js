import API from '../api/axiosConfig';

const getAllMatchs = async () => {
  const response = await API.get( '/match' ) ;
  return response.data;
};

// On assigne à une variable
const matchService = {
  getAllMatchs
};

export default matchService ;