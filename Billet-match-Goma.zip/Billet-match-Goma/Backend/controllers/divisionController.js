const db = require('../config/db');

// =====================
// VOIR TOUTES LES DIVISIONS
// =====================
exports.getAll = async (req, res) => {
    try {
        const [rows] = await db.query("SELECT * FROM division");
        res.json(rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
};

// =====================
// VOIR UNE DIVISION
// =====================
exports.getOne = async (req, res) => {
    try {
        const { id } = req.params;

        const [rows] = await db.query(
            "SELECT * FROM division WHERE id = ?",
            [id]
        );

        if (rows.length === 0) {
            return res.status(404).json({ message: "Division non trouvée" });
        }

        res.json(rows[0]);

    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
};

// =====================
// CREER DIVISION
// =====================
exports.create = async (req, res) => {
    try {
        const { nom_division } = req.body;

        if (!nom_division) {
            return res.status(400).json({
                error: "nom_division est requis"
            });
        }

        const [result] = await db.query(
            "INSERT INTO division (nom_division) VALUES (?)",
            [nom_division]
        );

        res.status(201).json({
            id: result.insertId,
            nom_division
        });

    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
};

// =====================
// MODIFIER DIVISION
// =====================
exports.update = async (req, res) => {
    try {
        const { id } = req.params;
        const { nom_division } = req.body;

        if (!nom_division) {
            return res.status(400).json({
                error: "nom_division est requis"
            });
        }

        const [result] = await db.query(
            "UPDATE division SET nom_division=? WHERE id=?",
            [nom_division, id]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({
                message: "Division non trouvée"
            });
        }

        res.json({ message: "Division mise à jour" });

    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
};

// =====================
// SUPPRIMER DIVISION
// =====================
exports.delete = async (req, res) => {
    try {
        const { id } = req.params;

        const [result] = await db.query(
            "DELETE FROM division WHERE id=?",
            [id]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({
                message: "Division non trouvée"
            });
        }

        res.json({ message: "Division supprimée" });

    } catch (err) {
        console.error(err);

        if (err.code === "ER_ROW_IS_REFERENCED_2") {
            return res.status(400).json({
                error: "Impossible de supprimer : division utilisée dans un championnat"
            });
        }

        res.status(500).json({ error: err.message });
    }
};