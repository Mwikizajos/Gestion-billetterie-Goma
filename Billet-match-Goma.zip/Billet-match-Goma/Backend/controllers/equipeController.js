const db = require('../config/db');

// 1. VOIR TOUT + RECHERCHE + PAGINATION (GET)
exports.getAll = async (req, res) => {
    try {
        // Paramètres de pagination
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 5;
        const offset = (page - 1) * limit;

        // Paramètre de recherche
        const { nom } = req.query;

        let query = "SELECT * FROM equipe";
        let countQuery = "SELECT COUNT(*) as total FROM equipe";
        let params = [];

        // Si recherche
        if (nom) {
            query += " WHERE Nom_equipe LIKE ?";
            countQuery += " WHERE Nom_equipe LIKE ?";
            params.push(`%${nom}%`);
        }

        // Ajouter pagination
        query += " LIMIT ? OFFSET ?";
        params.push(limit, offset);

        // Exécution
        const [rows] = await db.query(query, params);

        // Total pour pagination
        const [countResult] = await db.query(
            countQuery,
            nom ? [`%${nom}%`] : []
        );

        const total = countResult[0].total;

        res.json({
            page,
            limit,
            total,
            totalPages: Math.ceil(total / limit),
            data: rows
        });

    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
};

// 2. VOIR UNE SEULE ÉQUIPE (GET BY ID)
exports.getOne = async (req, res) => {
    try {
        const { id } = req.params;

        const [rows] = await db.query(
            "SELECT * FROM equipe WHERE id = ?",
            [id]
        );

        if (rows.length === 0) {
            return res.status(404).json({ message: "Équipe non trouvée" });
        }

        res.json(rows[0]);

    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
};

// 3. AJOUTER (POST)
exports.create = async (req, res) => {
    try {
        const { Nom_equipe, sigle_equipe, ville } = req.body;

        // Validation simple
        if (!Nom_equipe || !sigle_equipe || !ville) {
            return res.status(400).json({ error: "Tous les champs sont requis" });
        }

        const [result] = await db.query(
            "INSERT INTO equipe (Nom_equipe, sigle_equipe, ville) VALUES (?, ?, ?)",
            [Nom_equipe, sigle_equipe, ville]
        );

        res.status(201).json({
            id: result.insertId,
            Nom_equipe,
            sigle_equipe,
            ville
        });

    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
};

// 4. MODIFIER (PUT)
exports.update = async (req, res) => {
    try {
        const { id } = req.params;
        const { Nom_equipe, sigle_equipe, ville } = req.body;

        // Validation simple
        if (!Nom_equipe || !sigle_equipe || !ville) {
            return res.status(400).json({ error: "Tous les champs sont requis" });
        }

        const [result] = await db.query(
            "UPDATE equipe SET Nom_equipe=?, sigle_equipe=?, ville=? WHERE id=?",
            [Nom_equipe, sigle_equipe, ville, id]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({ message: "Équipe non trouvée" });
        }

        res.json({ message: "Équipe mise à jour !" });

    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
};

// 5. SUPPRIMER (DELETE)
exports.delete = async (req, res) => {
    try {
        const { id } = req.params;

        const [result] = await db.query(
            "DELETE FROM equipe WHERE id = ?",
            [id]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({ message: "Équipe non trouvée" });
        }

        res.json({ message: "Équipe supprimée !" });

    } catch (err) {
        console.error(err);

        if (err.code === "ER_ROW_IS_REFERENCED_2") {
            return res.status(400).json({
                error: "Impossible de supprimer : cette équipe est liée à d'autres données"
            });
        }

        res.status(500).json({ error: err.message });
    }
};