const db = require('../config/db');
//const bcrypt = require('bcrypt');
const bcrypt = require('bcryptjs');

// voir admins
exports.getAdmins = async (req,res)=>{
    try{
        const [rows] = await db.query(
            "SELECT id, nom, telephone, role FROM utilisateurs WHERE role='admin'"
        );

        res.json(rows);
    }catch(err){
        res.status(500).json({
            error: err.message
        });
    }
};

// créer admin
exports.createAdmin = async(req,res)=>{
    try{
        const {nom,telephone,password} = req.body;

        if(!nom || !telephone || !password){
            return res.status(400).json({
                error:"Tous les champs sont requis"
            });
        }

        const hashedPassword = await bcrypt.hash(password,10);

        await db.query(
            `INSERT INTO utilisateurs(nom,telephone,password,role)
             VALUES(?,?,?,?)`,
            [nom,telephone,hashedPassword,"admin"]
        );

        res.json({
            message:"Admin créé avec succès"
        });

    }catch(err){
        res.status(500).json({
            error: err.message
        });
    }
};

// supprimer admin
exports.deleteAdmin = async(req,res)=>{
    try{
        const {id} = req.params;

        await db.query(
            "DELETE FROM utilisateurs WHERE id=? AND role='admin'",
            [id]
        );

        res.json({
            message:"Admin supprimé"
        });

    }catch(err){
        res.status(500).json({
            error: err.message
        });
    }
};