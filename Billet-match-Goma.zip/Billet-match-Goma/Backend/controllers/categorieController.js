const db = require('../config/db');

// 1. VOIR TOUT
exports.getAll = async (req, res) => {
    try {
        const [rows] = await db.query("SELECT * FROM categorie_match");
        res.json(rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
};

// 2. VOIR UNE CATEGORIE
exports.getOne = async (req, res) => {
    try {
        const { id } = req.params;

        const [rows] = await db.query(
            "SELECT * FROM categorie_match WHERE id = ?",
            [id]
        );

        if (rows.length === 0) {
            return res.status(404).json({ message: "Catégorie non trouvée" });
        }

        res.json(rows[0]);

    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
};

// 3. AJOUTER
exports.create = async (req, res) => {
    try {
        const { types_categorie } = req.body;

        const valeursValides = ['amical', 'championat'];

        // Validation
        if (!types_categorie || !valeursValides.includes(types_categorie)) {
            return res.status(400).json({
                error: "Valeur invalide (amical ou championat)"
            });
        }

        const [result] = await db.query(
            "INSERT INTO categorie_match (types_categorie) VALUES (?)",
            [types_categorie]
        );

        res.status(201).json({
            id: result.insertId,
            types_categorie
        });

    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
};

// 4. MODIFIER
exports.update = async (req, res) => {
    try {
        const { id } = req.params;
        const { types_categorie } = req.body;

        const valeursValides = ['amical', 'championat'];

        // Validation
        if (!types_categorie || !valeursValides.includes(types_categorie)) {
            return res.status(400).json({
                error: "Valeur invalide (amical ou championat)"
            });
        }

        const [result] = await db.query(
            "UPDATE categorie_match SET types_categorie=? WHERE id=?",
            [types_categorie, id]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({ message: "Catégorie non trouvée" });
        }

        res.json({ message: "Catégorie mise à jour" });

    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
};

// 5. SUPPRIMER
exports.delete = async (req, res) => {
    try {
        const { id } = req.params;

        const [result] = await db.query(
            "DELETE FROM categorie_match WHERE id = ?",
            [id]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({ message: "Catégorie non trouvée" });
        }

        res.json({ message: "Catégorie supprimée" });

    } catch (err) {
        console.error(err);

        if (err.code === "ER_ROW_IS_REFERENCED_2") {
            return res.status(400).json({
                error: "Impossible de supprimer : catégorie utilisée ailleurs"
            });
        }

        res.status(500).json({ error: err.message });
    }
};