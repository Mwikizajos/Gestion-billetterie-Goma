const db = require('../config/db');
const bcrypt = require('bcryptjs');

exports.register = async (req, res) => {
    try {
        const { nom, email, mot_de_passe } = req.body;
        // Hachage du mot de passe
        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(mot_de_passe, salt);

        const sql = "INSERT INTO utilisateurs (nom, email, mot_de_passe) VALUES (?, ?, ?)";
        await db.query(sql, [nom, email, hashedPassword]);
        
        res.status(201).json({ message: "Utilisateur créé avec succès !" });
    } catch (error) {
        res.status(500).json({ error: "L'email est peut-être déjà utilisé." });
    }
};

exports.login = async (req, res) => {
    try {
        const { email, mot_de_passe } = req.body;
        const [users] = await db.query("SELECT * FROM utilisateurs WHERE email = ?", [email]);

        if (users.length === 0) return res.status(404).json({ message: "Utilisateur non trouvé" });

        const isMatch = await bcrypt.compare(mot_de_passe, users[0].mot_de_passe);
        if (!isMatch) return res.status(400).json({ message: "Mot de passe incorrect" });

        res.json({ message: "Connexion réussie", user: { id: users[0].id, nom: users[0].nom } });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};