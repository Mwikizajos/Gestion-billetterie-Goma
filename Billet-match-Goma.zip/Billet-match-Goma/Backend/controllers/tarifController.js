const db = require('../config/db');

// 1. VOIR LES TARIFS D’UN MATCH
exports.getTarifsByMatch = async (req, res) => {
    try {
        const { idMatch } = req.params;

        const [rows] = await db.query(
            "SELECT * FROM tarifs WHERE idMatch = ?",
            [idMatch]
        );

        res.json(rows);

    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
};

// 2. AJOUTER UN TARIF
exports.createTarif = async (req, res) => {
    try {
        const { idMatch, type_place, prix, nombre_places_total } = req.body;

        const typesValides = ['Standard', 'VIP'];

        // Validation
        if (!idMatch || !type_place || !prix || !nombre_places_total) {
            return res.status(400).json({
                error: "Tous les champs sont requis"
            });
        }

        if (!typesValides.includes(type_place)) {
            return res.status(400).json({
                error: "type_place invalide (Standard ou VIP)"
            });
        }

        if (prix < 0 || nombre_places_total <= 0) {
            return res.status(400).json({
                error: "Prix ou nombre de places invalide"
            });
        }

        // Vérifier si le match existe
        const [match] = await db.query(
            "SELECT id FROM matchs WHERE id = ?",
            [idMatch]
        );

        if (match.length === 0) {
            return res.status(400).json({
                error: "Match invalide"
            });
        }

        // Vérifier si tarif déjà existant pour ce type
        const [existing] = await db.query(
            "SELECT id FROM tarifs WHERE idMatch = ? AND type_place = ?",
            [idMatch, type_place]
        );

        if (existing.length > 0) {
            return res.status(400).json({
                error: "Ce type de place existe déjà pour ce match"
            });
        }

        const [result] = await db.query(
            "INSERT INTO tarifs (idMatch, type_place, prix, nombre_places_total) VALUES (?, ?, ?, ?)",
            [idMatch, type_place, prix, nombre_places_total]
        );

        res.status(201).json({
            id: result.insertId,
            message: "Tarif configuré"
        });

    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
};

// 3. MODIFIER UN TARIF
exports.updateTarif = async (req, res) => {
    try {
        const { id } = req.params;
        const { type_place, prix, nombre_places_total } = req.body;

        const typesValides = ['Standard', 'VIP'];

        if (!type_place || !prix || !nombre_places_total) {
            return res.status(400).json({
                error: "Tous les champs sont requis"
            });
        }

        if (!typesValides.includes(type_place)) {
            return res.status(400).json({
                error: "type_place invalide"
            });
        }

        const [result] = await db.query(
            "UPDATE tarifs SET type_place=?, prix=?, nombre_places_total=? WHERE id=?",
            [type_place, prix, nombre_places_total, id]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({ message: "Tarif non trouvé" });
        }

        res.json({ message: "Tarif modifié" });

    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
};

// 4. SUPPRIMER UN TARIF
exports.deleteTarif = async (req, res) => {
    try {
        const { id } = req.params;

        const [result] = await db.query(
            "DELETE FROM tarifs WHERE id = ?",
            [id]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({ message: "Tarif non trouvé" });
        }

        res.json({ message: "Tarif supprimé" });

    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
};