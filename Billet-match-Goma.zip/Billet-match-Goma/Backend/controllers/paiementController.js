const db = require('../config/db');

// 1. VOIR TOUS LES PAIEMENTS + PAGINATION + RECHERCHE
exports.getAll = async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 5;
        const offset = (page - 1) * limit;

        const { statut, operateur } = req.query;

        let query = "SELECT * FROM paiements";
        let countQuery = "SELECT COUNT(*) as total FROM paiements";
        let conditions = [];
        let params = [];

        // Filtres
        if (statut) {
            conditions.push("statut = ?");
            params.push(statut);
        }

        if (operateur) {
            conditions.push("operateur = ?");
            params.push(operateur);
        }

        if (conditions.length > 0) {
            const whereClause = " WHERE " + conditions.join(" AND ");
            query += whereClause;
            countQuery += whereClause;
        }

        query += " ORDER BY date_paiement DESC LIMIT ? OFFSET ?";
        params.push(limit, offset);

        const [rows] = await db.query(query, params);

        const [countResult] = await db.query(
            countQuery,
            params.slice(0, conditions.length)
        );

        const total = countResult[0].total;

        res.json({
            page,
            limit,
            total,
            totalPages: Math.ceil(total / limit),
            data: rows
        });

    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
};

// 2. VOIR UN PAIEMENT
exports.getOne = async (req, res) => {
    try {
        const { id } = req.params;

        const [rows] = await db.query(
            "SELECT * FROM paiements WHERE id = ?",
            [id]
        );

        if (rows.length === 0) {
            return res.status(404).json({ message: "Paiement non trouvé" });
        }

        res.json(rows[0]);

    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
};

// 3. METTRE À JOUR LE STATUT
exports.updateStatut = async (req, res) => {
    try {
        const { statut } = req.body;
        const { id } = req.params;

        const statutsValides = ['En attente', 'Succes', 'Echec'];

        // Validation
        if (!statut || !statutsValides.includes(statut)) {
            return res.status(400).json({
                error: "Statut invalide (En attente, Succes, Echec)"
            });
        }

        const [result] = await db.query(
            "UPDATE paiements SET statut=? WHERE id=?",
            [statut, id]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({ message: "Paiement non trouvé" });
        }

        res.json({ message: "Statut paiement mis à jour" });

    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
};

// 4. SUPPRIMER UN PAIEMENT (optionnel mais utile)
exports.delete = async (req, res) => {
    try {
        const { id } = req.params;

        const [result] = await db.query(
            "DELETE FROM paiements WHERE id = ?",
            [id]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({ message: "Paiement non trouvé" });
        }

        res.json({ message: "Paiement supprimé" });

    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
};