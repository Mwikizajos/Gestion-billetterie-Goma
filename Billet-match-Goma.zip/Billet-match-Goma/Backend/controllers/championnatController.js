const db = require('../config/db');

// 1. VOIR TOUS LES CHAMPIONNATS (avec division)
exports.getAll = async (req, res) => {
    try {
        const sql = `
            SELECT c.*, d.nom_division 
            FROM championat c
            JOIN division d ON c.idDivision = d.id
        `;

        const [rows] = await db.query(sql);
        res.json(rows);

    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
};

// 2. VOIR UN CHAMPIONNAT
exports.getOne = async (req, res) => {
    try {
        const { id } = req.params;

        const sql = `
            SELECT c.*, d.nom_division 
            FROM championat c
            JOIN division d ON c.idDivision = d.id
            WHERE c.id = ?
        `;

        const [rows] = await db.query(sql, [id]);

        if (rows.length === 0) {
            return res.status(404).json({ message: "Championnat non trouvé" });
        }

        res.json(rows[0]);

    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
};

// 3. AJOUTER
exports.create = async (req, res) => {
    try {
        const { nom_championat, idDivision } = req.body;

        // Validation
        if (!nom_championat || !idDivision) {
            return res.status(400).json({
                error: "nom_championat et idDivision sont requis"
            });
        }

        // Vérifier si division existe
        const [division] = await db.query(
            "SELECT * FROM division WHERE id = ?",
            [idDivision]
        );

        if (division.length === 0) {
            return res.status(400).json({
                error: "Division invalide"
            });
        }

        const [result] = await db.query(
            "INSERT INTO championat (nom_championat, idDivision) VALUES (?, ?)",
            [nom_championat, idDivision]
        );

        res.status(201).json({
            id: result.insertId,
            nom_championat,
            idDivision
        });

    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
};

// 4. MODIFIER
exports.update = async (req, res) => {
    try {
        const { id } = req.params;
        const { nom_championat, idDivision } = req.body;

        // Validation
        if (!nom_championat || !idDivision) {
            return res.status(400).json({
                error: "nom_championat et idDivision sont requis"
            });
        }

        // Vérifier division
        const [division] = await db.query(
            "SELECT * FROM division WHERE id = ?",
            [idDivision]
        );

        if (division.length === 0) {
            return res.status(400).json({
                error: "Division invalide"
            });
        }

        const [result] = await db.query(
            "UPDATE championat SET nom_championat=?, idDivision=? WHERE id=?",
            [nom_championat, idDivision, id]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({
                message: "Championnat non trouvé"
            });
        }

        res.json({ message: "Championnat mis à jour" });

    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
};

// 5. SUPPRIMER
exports.delete = async (req, res) => {
    try {
        const { id } = req.params;

        const [result] = await db.query(
            "DELETE FROM championat WHERE id = ?",
            [id]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({
                message: "Championnat non trouvé"
            });
        }

        res.json({ message: "Championnat supprimé" });

    } catch (err) {
        console.error(err);

        if (err.code === "ER_ROW_IS_REFERENCED_2") {
            return res.status(400).json({
                error: "Impossible de supprimer : des matchs sont liés à ce championnat"
            });
        }

        res.status(500).json({ error: err.message });
    }
};