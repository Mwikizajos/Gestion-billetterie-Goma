const db = require('../config/db');
const { v4: uuidv4 } = require('uuid');

// =====================
// VOIR TOUS LES BILLETS
// =====================
exports.getAll = async (req, res) => {
    try {
        const sql = `
            SELECT b.*, u.nom, m.date_match, t.type_place, t.prix
            FROM billets b
            JOIN utilisateurs u ON b.iduser = u.id
            JOIN matchs m ON b.idmatch = m.id
            JOIN tarifs t ON b.idTarif = t.id
        `;

        const [rows] = await db.query(sql);
        res.json(rows);

    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
};

// =====================
// CREER UN BILLET
// =====================
exports.create = async (req, res) => {
    try {
        const { iduser, idmatch, idTarif, idPaiement } = req.body;

        if (!iduser || !idmatch || !idTarif || !idPaiement) {
            return res.status(400).json({
                error: "Tous les champs sont requis"
            });
        }

        // Génération code QR (simple)
        const codeQR = uuidv4();

        const [result] = await db.query(
            `INSERT INTO billets (iduser, idmatch, idTarif, idPaiement, codeQR)
             VALUES (?, ?, ?, ?, ?)`,
            [iduser, idmatch, idTarif, idPaiement, codeQR]
        );

        res.status(201).json({
            id: result.insertId,
            codeQR,
            message: "Billet créé avec succès"
        });

    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
};

// =====================
// VERIFIER UN BILLET (QR / VALIDATION)
// =====================
exports.verify = async (req, res) => {
    try {
        const { codeQR } = req.params;

        const [rows] = await db.query(
            "SELECT * FROM billets WHERE codeQR = ?",
            [codeQR]
        );

        if (rows.length === 0) {
            return res.status(404).json({ message: "Billet invalide" });
        }

        res.json(rows[0]);

    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
};

// =====================
// ANNULER / INVALIDER BILLET
// =====================
exports.invalidate = async (req, res) => {
    try {
        const { id } = req.params;

        const [result] = await db.query(
            "UPDATE billets SET estValide = false WHERE id = ?",
            [id]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({ message: "Billet non trouvé" });
        }

        res.json({ message: "Billet invalidé" });

    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
};