const db = require('../config/db');

// 1. VOIR TOUS LES MATCHS
exports.getAll = async (req, res) => {
    try {
        const sql = `
            SELECT m.*,
                   e1.Nom_equipe AS domicile,
                   e2.Nom_equipe AS exterieur,
                   s.nom_stade,
                   c.types_categorie
            FROM matchs m
            JOIN equipe e1 ON m.equipe_domicile = e1.id
            JOIN equipe e2 ON m.equipe_exterieur = e2.id
            JOIN stade s ON m.stade = s.id
            JOIN categorie_match c ON m.idCategorie_match = c.id
            ORDER BY m.date_match DESC
        `;

        const [rows] = await db.query(sql);
        res.json(rows);

    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
};

// 2. VOIR UN MATCH
exports.getById = async (req, res) => {
    try {
        const { id } = req.params;

        const [rows] = await db.query(
            "SELECT * FROM matchs WHERE id = ?",
            [id]
        );

        if (rows.length === 0) {
            return res.status(404).json({ message: "Match non trouvé" });
        }

        res.json(rows[0]);

    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
};

// 3. CREER UN MATCH
exports.create = async (req, res) => {
    try {
        const { equipe_domicile, equipe_exterieur, stade, idCategorie_match, date_match } = req.body;

        // Validation
        if (!equipe_domicile || !equipe_exterieur || !stade || !idCategorie_match || !date_match) {
            return res.status(400).json({
                error: "Tous les champs sont requis"
            });
        }

        if (equipe_domicile === equipe_exterieur) {
            return res.status(400).json({
                error: "Une équipe ne peut pas jouer contre elle-même"
            });
        }

        // Vérifications existence
        const [equipe1] = await db.query("SELECT id FROM equipe WHERE id=?", [equipe_domicile]);
        const [equipe2] = await db.query("SELECT id FROM equipe WHERE id=?", [equipe_exterieur]);
        const [stadeCheck] = await db.query("SELECT id FROM stade WHERE id=?", [stade]);
        const [categorie] = await db.query("SELECT id FROM categorie_match WHERE id=?", [idCategorie_match]);

        if (equipe1.length === 0 || equipe2.length === 0) {
            return res.status(400).json({ error: "Équipe invalide" });
        }

        if (stadeCheck.length === 0) {
            return res.status(400).json({ error: "Stade invalide" });
        }

        if (categorie.length === 0) {
            return res.status(400).json({ error: "Catégorie invalide" });
        }

        const [result] = await db.query(
            `INSERT INTO matchs (equipe_domicile, equipe_exterieur, stade, idCategorie_match, date_match)
             VALUES (?, ?, ?, ?, ?)`,
            [equipe_domicile, equipe_exterieur, stade, idCategorie_match, date_match]
        );

        res.status(201).json({
            id: result.insertId,
            message: "Match programmé !"
        });

    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
};

// 4. MODIFIER
exports.update = async (req, res) => {
    try {
        const { id } = req.params;
        const { equipe_domicile, equipe_exterieur, stade, idCategorie_match, date_match } = req.body;

        if (!equipe_domicile || !equipe_exterieur || !stade || !idCategorie_match || !date_match) {
            return res.status(400).json({
                error: "Tous les champs sont requis"
            });
        }

        if (equipe_domicile === equipe_exterieur) {
            return res.status(400).json({
                error: "Une équipe ne peut pas jouer contre elle-même"
            });
        }

        const [result] = await db.query(
            `UPDATE matchs 
             SET equipe_domicile = ?, 
                 equipe_exterieur = ?, 
                 stade = ?, 
                 idCategorie_match = ?, 
                 date_match = ?
             WHERE id = ?`,
            [equipe_domicile, equipe_exterieur, stade, idCategorie_match, date_match, id]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({ message: "Match non trouvé" });
        }

        res.json({ message: "Match modifié avec succès !" });

    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
};

// 5. SUPPRIMER
exports.delete = async (req, res) => {
    try {
        const { id } = req.params;

        const [result] = await db.query(
            "DELETE FROM matchs WHERE id = ?",
            [id]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({ message: "Match non trouvé" });
        }

        res.json({ message: "Match supprimé avec succès !" });

    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
};