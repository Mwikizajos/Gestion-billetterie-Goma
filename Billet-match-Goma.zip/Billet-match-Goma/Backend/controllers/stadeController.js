const db = require('../config/db');

// 1. VOIR TOUS LES STADES
exports.getAll = async (req, res) => {
    try {
        const [rows] = await db.query("SELECT * FROM stade");
        res.json(rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
};

// 2. VOIR UN STADE
exports.getOne = async (req, res) => {
    try {
        const { id } = req.params;

        const [rows] = await db.query(
            "SELECT * FROM stade WHERE id = ?",
            [id]
        );

        if (rows.length === 0) {
            return res.status(404).json({ message: "Stade non trouvé" });
        }

        res.json(rows[0]);

    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
};

// 3. AJOUTER
exports.create = async (req, res) => {
    try {
        const { nom_stade, capacite, capacite_place_VIP, adresse } = req.body;

        // Validation
        if (!nom_stade || !capacite || !capacite_place_VIP || !adresse) {
            return res.status(400).json({
                error: "Tous les champs sont requis"
            });
        }

        if (capacite < 0 || capacite_place_VIP < 0) {
            return res.status(400).json({
                error: "Les capacités doivent être positives"
            });
        }

        const [result] = await db.query(
            "INSERT INTO stade (nom_stade, capacite, capacite_place_VIP, adresse) VALUES (?, ?, ?, ?)",
            [nom_stade, capacite, capacite_place_VIP, adresse]
        );

        res.status(201).json({
            id: result.insertId,
            nom_stade,
            capacite,
            capacite_place_VIP,
            adresse
        });

    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
};

// 4. MODIFIER
exports.update = async (req, res) => {
    try {
        const { id } = req.params;
        const { nom_stade, capacite, capacite_place_VIP, adresse } = req.body;

        // Validation
        if (!nom_stade || !capacite || !capacite_place_VIP || !adresse) {
            return res.status(400).json({
                error: "Tous les champs sont requis"
            });
        }

        if (capacite < 0 || capacite_place_VIP < 0) {
            return res.status(400).json({
                error: "Les capacités doivent être positives"
            });
        }

        const [result] = await db.query(
            "UPDATE stade SET nom_stade=?, capacite=?, capacite_place_VIP=?, adresse=? WHERE id=?",
            [nom_stade, capacite, capacite_place_VIP, adresse, id]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({ message: "Stade non trouvé" });
        }

        res.json({ message: "Stade modifié !" });

    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
};

// 5. SUPPRIMER
exports.delete = async (req, res) => {
    try {
        const { id } = req.params;

        const [result] = await db.query(
            "DELETE FROM stade WHERE id = ?",
            [id]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({ message: "Stade non trouvé" });
        }

        res.json({ message: "Stade supprimé !" });

    } catch (err) {
        console.error(err);

        if (err.code === "ER_ROW_IS_REFERENCED_2") {
            return res.status(400).json({
                error: "Impossible de supprimer : ce stade est lié à des matchs"
            });
        }

        res.status(500).json({ error: err.message });
    }
};