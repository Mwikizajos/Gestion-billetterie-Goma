const db = require('../config/db' );
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken'); // Importation obligatoire ici !


exports.getAll = async (req, res) => {
    try {
        const [rows] = await db.query("SELECT * FROM utilisateurs") ;
        res.json(rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
};

// INSCRIPTION
exports.register = async (req, res) => {
    try {
        const { nom, telephone, password, role } = req.body;

        // Validation
        if (!nom || !telephone || !password) {
            return res.status(400).json({
                error: "Nom, téléphone et mot de passe sont requis"
            });
        }

        // Vérifier si téléphone existe déjà
        const [existing] = await db.query(
            "SELECT id FROM utilisateurs WHERE telephone = ?",
            [telephone]
        );

        if (existing.length > 0) {
            return res.status(400).json({
                message: "Ce numéro est déjà utilisé"
            });
        }

        const hashedPassword = await bcrypt.hash(password, 10);

        const [result] = await db.query(
            "INSERT INTO utilisateurs (nom, telephone, password, role) VALUES (?, ?, ?, ?)",
            [nom, telephone, hashedPassword, role || 'client' ]
        );

        res.status(201).json({
            id: result.insertId,
            nom,
            telephone,
            role: role || 'client',
            message: "Utilisateur créé avec succès"
        });

    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
};

// =====================
// CONNEXION
// =====================
exports.login = async (req, res) => {
    try {
        const { telephone, password } = req.body;
        
        // 1. Chercher l'utilisateur par téléphone
        const [rows] = await db.query("SELECT * FROM utilisateurs WHERE telephone = ?", [telephone]);
        
        if (rows.length === 0) {
            return res.status(404).json({ message: "Utilisateur non trouvé." });
        }

        const user = rows[0];

        // 2. Vérifier le mot de passe
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(400).json({ message: "Mot de passe incorrect." });
        }

        // 3. GÉNÉRATION DU TOKEN JWT
        // On met l'ID et le ROLE dans le token
        const token = jwt.sign(
            { id: user.id, role: user.role }, 
            process.env.JWT_SECRET, 
            { expiresIn: '24h' } // Le token durera 1 jour
        );

        // 4. Envoyer la réponse avec le token
        res.json({
            message: "Connexion réussie !",
            token: token,
            user: {
                id: user.id,
                nom: user.nom,
                role: user.role
            }
        });

    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};