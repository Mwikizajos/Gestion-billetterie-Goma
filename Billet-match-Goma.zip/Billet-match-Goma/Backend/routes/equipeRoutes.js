const express = require('express');
const router = express.Router();
const equipeCtrl = require('../controllers/equipeController');
const auth = require('../middlewares/authMiddleware');

// CRUD + recherche + pagination
router.get('/', auth, equipeCtrl.getAll);       // GET /equipes?page=1&limit=5&nom=real
router.get('/:id', auth, equipeCtrl.getOne);    // GET /equipes/1
router.post('/', auth, equipeCtrl.create);      // POST
router.put('/:id', auth, equipeCtrl.update);    // PUT
router.delete('/:id', auth, equipeCtrl.delete); // DELETE

module.exports = router;