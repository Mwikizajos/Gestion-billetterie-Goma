const express = require('express');
const router = express.Router();
const championatCtrl = require('../controllers/championnatController');
const auth = require('../middlewares/authMiddleware');

// CRUD championats
router.get('/', auth, championatCtrl.getAll);       // Voir tout
router.get('/:id', auth, championatCtrl.getOne);    // Voir un
router.post('/', auth, championatCtrl.create);      // Ajouter
router.put('/:id', auth, championatCtrl.update);    // Modifier
router.delete('/:id', auth, championatCtrl.delete); // Supprimer

module.exports = router;