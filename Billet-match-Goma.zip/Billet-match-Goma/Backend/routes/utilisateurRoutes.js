const express = require('express');
const router = express.Router();
const authCtrl = require('../controllers/utilisateurController');
const auth = require('../middlewares/authMiddleware');

// Auth routes
router.get('/', authCtrl.getAll);
router.post('/register' , authCtrl.register); // inscription
router.post('/login', authCtrl.login);       // connexion

module.exports = router;