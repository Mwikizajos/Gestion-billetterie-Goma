const express = require('express');
const router = express.Router();
const tarifCtrl = require('../controllers/tarifController');
const auth = require('../middlewares/authMiddleware');

// Routes tarifs
router.get('/match/:idMatch', auth, tarifCtrl.getTarifsByMatch); // Voir tarifs d’un match
router.post('/', auth, tarifCtrl.createTarif);                   // Ajouter tarif
router.put('/:id', auth, tarifCtrl.updateTarif);                 // Modifier tarif
router.delete('/:id', auth, tarifCtrl.deleteTarif);              // Supprimer tarif

module.exports = router;