const express = require('express');
const router = express.Router();
const billetCtrl = require('../controllers/billetController');
const auth = require('../middlewares/authMiddleware');

router.get('/', auth, billetCtrl.getAll);                 // tous les billets
router.post('/', auth, billetCtrl.create);                // créer billet
router.get('/verify/:codeQR', auth,  billetCtrl.verify);   // vérifier QR
router.put('/invalidate/:id', auth, billetCtrl.invalidate); // invalider billet

module.exports = router;