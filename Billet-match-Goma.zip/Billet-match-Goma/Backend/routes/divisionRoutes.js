const express = require('express');
const router = express.Router();
const divisionCtrl = require('../controllers/divisionController');
const auth = require('../middlewares/authMiddleware');

router.get('/', auth, divisionCtrl.getAll);
router.get('/:id', auth, divisionCtrl.getOne);
router.post('/', auth, divisionCtrl.create);
router.put('/:id', auth, divisionCtrl.update);
router.delete('/:id', auth, divisionCtrl.delete);

module.exports = router;