const express = require('express');
const router = express.Router();
const matchCtrl = require('../controllers/matchController');
const auth = require('../middlewares/authMiddleware');

// CRUD matchs
router.get('/', matchCtrl.getAll);       // Voir tous
router.get('/:id', matchCtrl.getById);   // Voir un match
router.post('/', auth, matchCtrl.create);      // Créer
router.put('/:id', auth, matchCtrl.update);    // Modifier
router.delete('/:id', auth, matchCtrl.delete); // Supprimer

module.exports = router;