const express = require('express');
const router = express.Router();
const paiementCtrl = require('../controllers/paiementController');
const auth = require('../middlewares/authMiddleware');

// Routes paiements
router.get('/', auth, paiementCtrl.getAll);            // GET /paiements?page=1&limit=5&statut=Succes
router.get('/:id', auth, paiementCtrl.getOne);         // GET /paiements/1
router.put('/:id', auth, paiementCtrl.updateStatut);  // Modifier statut
router.delete('/:id', auth, paiementCtrl.delete);     // Supprimer (optionnel)

module.exports = router;