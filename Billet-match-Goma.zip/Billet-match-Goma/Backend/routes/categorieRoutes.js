const express = require('express');
const router = express.Router();
const categorieCtrl = require('../controllers/categorieController' );
const auth = require('../middlewares/authMiddleware');

// CRUD catégories
router.get('/', auth, categorieCtrl.getAll);       // Voir tout
router.get('/:id', auth, categorieCtrl.getOne);    // Voir une catégorie
router.post('/', auth, categorieCtrl.create);      // Ajouter
router.put('/:id', auth, categorieCtrl.update);    // Modifier
router.delete('/:id', auth, categorieCtrl.delete); // Supprimer

module.exports = router;