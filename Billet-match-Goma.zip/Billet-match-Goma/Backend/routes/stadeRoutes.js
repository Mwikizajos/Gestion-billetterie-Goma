const express = require('express');
const router = express.Router();
const stadeCtrl = require('../controllers/stadeController');
const auth = require('../middlewares/authMiddleware');

// CRUD stades
router.get('/', auth, stadeCtrl.getAll);       // Voir tout
router.get('/:id', auth, stadeCtrl.getOne);    // Voir un stade
router.post('/', auth, stadeCtrl.create);      // Ajouter
router.put('/:id', auth, stadeCtrl.update);    // Modifier
router.delete('/:id', auth, stadeCtrl.delete); // Supprimer

module.exports = router;