const express = require('express');
const router = express.Router();
const adminCtrl = require('../controllers/adminController');
const auth = require('../middlewares/authMiddleware');

router.get('/', auth, adminCtrl.getAdmins);
router.post('/', auth, adminCtrl.createAdmin);
router.delete('/:id', auth, adminCtrl.deleteAdmin);

module.exports = router;