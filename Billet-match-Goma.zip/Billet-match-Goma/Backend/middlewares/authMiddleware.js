const jwt = require('jsonwebtoken');

module.exports = (req, res, next) => {
    // 1. On récupère le token dans l'en-tête "Authorization"
    const authHeader = req.header('Authorization');

    // 2. Si pas de header ou pas de token, on bloque
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return res.status(401).json({ message: "Accès refusé. Connectez-vous d'abord." });
    }

    // 3. On extrait le token (on enlève le mot "Bearer ")
    const token = authHeader.split(' ')[1];

    try {
        // 4. On vérifie la signature avec ta clé secrète du .env
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        
        // 5. On stocke les infos décodées dans 'req.user' pour les utiliser plus tard
        req.user = decoded;
        
        // 6. On laisse passer à la suite (le contrôleur)
        next();
    } catch (error) {
        res.status(401).json({ message: "Badge invalide ou expiré." });
    }
};