const express= require('express');
const cors= require('cors');
require('dotenv').config();

//importation des routes 
const matchRoutes = require('./routes/matchRoutes' );
const authRoutes = require('./routes/authRoutes');
const utilisateurRoutes = require('./routes/utilisateurRoutes');
const tarifRoutes = require('./routes/tarifRoutes');
const billetRoutes = require('./routes/billetRoutes');
const categorieRoutes = require ('./routes/categorieRoutes');
const championatRoutes = require('./routes/championatRoutes');
const divisionRoutes = require('./routes/divisionRoutes');
const equipeRoutes = require('./routes/equipeRoutes');
const stadeRoutes = require('./routes/stadeRoutes');
const paiementRoutes = require('./routes/paiementRoutes');
const adminRoutes = require ('./routes/adminRoutes');


const app = express();

//Middlewares
app.use(cors());
app.use(express.json());

//utilisation des routes 
app.use('/api/match', matchRoutes);
app.use('/api/auth', authRoutes);
app.use('/api/utilisateurs', utilisateurRoutes);
app.use('/api/tarifs', tarifRoutes);
app.use('/api/billet' , billetRoutes);
app.use('/api/categorie', categorieRoutes);
app.use('/api/championnat', championatRoutes);
app.use('/api/division', divisionRoutes);
app.use('/api/equipe', equipeRoutes);
app.use('/api/stade', stadeRoutes);
app.use('/api/paiement', paiementRoutes);
app.use('/api/admins', adminRoutes);


const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
    console.log(`Serveur Goma Foot lancé sur le port ${PORT}` );
});